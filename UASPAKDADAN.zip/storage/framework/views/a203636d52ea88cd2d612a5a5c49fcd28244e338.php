<?php /* C:\xampp\htdocs\UASPAKDADAN\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php */ ?>
<?php echo e($slot); ?>: <?php echo e($url); ?>

