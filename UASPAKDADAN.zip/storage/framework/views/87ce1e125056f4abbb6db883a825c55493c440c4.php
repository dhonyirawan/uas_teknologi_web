<?php /* C:\xampp\htdocs\laravel\Quis Web2.0_AgusHartanto_d11161002\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php */ ?>
<?php echo e($slot); ?>: <?php echo e($url); ?>

